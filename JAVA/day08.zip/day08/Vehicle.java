package com.shinhan.day08;


@FunctionalInterface
public interface Vehicle {
	public void run();
}
