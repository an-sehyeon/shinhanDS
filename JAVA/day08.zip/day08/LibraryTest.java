package com.shinhan.day08;

import com.shinhan.myapp.Book;

public class LibraryTest {

	public static void main(String[] args) {
		Book b = new Book("자바", 20000);
		System.out.println(b.getTitle());

	}

}
