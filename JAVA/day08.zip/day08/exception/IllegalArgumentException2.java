package com.shinhan.day08.exception;

public class IllegalArgumentException2 extends RuntimeException{

	IllegalArgumentException2(String str){
		super(str);
	}
}
