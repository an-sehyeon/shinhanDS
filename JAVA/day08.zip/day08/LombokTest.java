package com.shinhan.day08;

public class LombokTest {

	public static void main(String[] args) {
		Computer aa = new Computer("A", "window", 100);
		System.out.println(aa);

	}

}
