package com.shinhan.day07.inter;

public interface Soundable {

	void sound();
}
