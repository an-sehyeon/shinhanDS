package com.shinhan.day07.lab4;

public interface Resizable {
   public abstract void resize(double s);
}
