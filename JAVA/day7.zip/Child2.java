package com.shinhan.day07;

public class Child2 extends Parent{
	public Child2() {
		super(0);
	}
	
	void call() {
		System.out.println(getScore());
	}
	
}
