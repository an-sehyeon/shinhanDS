package com.shinhan.day07;

public class Computer extends Machine {

	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}

}