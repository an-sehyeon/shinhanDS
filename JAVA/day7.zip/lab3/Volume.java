package com.shinhan.day07.lab3;

public interface Volume {
	
	
	public abstract void volumeUp(int level);
	public abstract void volumeDown(int level);
	 
}
