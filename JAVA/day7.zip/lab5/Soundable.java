package com.shinhan.day07.lab5;

public interface Soundable {
	public String sound();
}