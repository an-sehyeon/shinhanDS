package com.shinhan.day07.lab5;

public class Cat implements Soundable {

	@Override
	public String sound() {
		// TODO Auto-generated method stub
		return "야옹";
	}
	
	void call() {
		System.out.println("!!!");
	}

}
