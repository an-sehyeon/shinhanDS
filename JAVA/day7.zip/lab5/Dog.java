package com.shinhan.day07.lab5;

public class Dog implements Soundable {

	@Override
	public String sound() {
		// TODO Auto-generated method stub
		return "멍멍";
	}

}
