package com.shinhan.day05;

public class Date {

	public Date(){
		System.out.println("오늘 날씨 좋아~");
	}

	//@Override
	public String toString() {
		return "Date []";
	}

	
	
	
}
