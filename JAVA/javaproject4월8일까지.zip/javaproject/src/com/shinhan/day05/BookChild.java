package com.shinhan.day05;

public class BookChild  {

	BookChild(){
		 
	}
//	void display() {
//		System.out.println("재정의");
//	}
	
}
