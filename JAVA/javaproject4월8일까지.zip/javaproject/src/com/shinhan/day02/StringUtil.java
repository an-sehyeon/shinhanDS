package com.shinhan.day02;

public class StringUtil {
    public static void hokeyGraphics(char cell, int size, boolean isRect)
    {
        //특정 도형을 출력하는 메소드 구현
    }

    public static void main(String args[])  {                 
        hokeyGraphics( '$', 4, false); 
    }
}

