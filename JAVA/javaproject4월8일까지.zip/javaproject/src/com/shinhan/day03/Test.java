package com.shinhan.day03;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println(">>>");
		int a = sc.nextInt();
		String b = sc.nextLine();
		System.out.println(a);
		System.out.println(b);
		

	}

}
