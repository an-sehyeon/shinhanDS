package com.shinhan.day04;

public class 타이어 {

}
