package com.shinhan.day04;

public enum JobResult {
  //상수들의 묶음. 나열
	SUCCESS,FAIL 
	
}
