package com.shinhan.day04;

//enum : 열거형, 상수들의 묶음 (나열)
public enum Grade {
	A,B,C,D,F;
	
}
