package com.shinhan.day04;

public class 기계 {

}
