package com.shinhan.day04;

public class CarTest {

	public static void main(String[] args) {
		f1();
	}

	private static void f1() {
		Car c1 = new Car(); //instance, c1의 object변수 
		
	}

}
