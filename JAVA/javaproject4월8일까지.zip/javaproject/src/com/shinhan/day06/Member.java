package com.shinhan.day06;

public class Member {
    //1.field(멤버변수-instance변수(non-static) )
	String name;
	String id;
	int age;

	public Member(String name, String id) {
		super();
		this.name = name;
		this.id = id;
	}


}
