package ch01.verify;

public class Example {
   //class는 변수 + 함수의 묶음 
	public static void main(String[] args) {
		System.out.println("개발자가 되기 위한 필수 개발 언어 Java");
	}
}
